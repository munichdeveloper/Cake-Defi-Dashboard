git clone --recurse-submodules git@github.com:munichdeveloper/Cake-Defi-Dashboard.git && docker-compose up
